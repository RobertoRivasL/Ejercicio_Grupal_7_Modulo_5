package models;

public class Administrativo {
}
